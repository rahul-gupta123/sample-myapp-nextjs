export interface Lob {
  name: string;
  code: string;
  status: string;
  createdOn: string;
}

export const lobColumns = ["LOB Name", "Code", "Status", "Created On"];

export const lobData: Lob[] = [
  { name: "Retail Banking", code: "RB001", status: "Active", createdOn: "2024-01-10" },
  { name: "Corporate Banking", code: "CB002", status: "Active", createdOn: "2024-02-15" },
  { name: "Wealth Management", code: "WM003", status: "Inactive", createdOn: "2023-12-05" },
  { name: "Insurance", code: "IN004", status: "Active", createdOn: "2024-03-20" },
  { name: "Loans", code: "LN005", status: "Active", createdOn: "2024-04-11" },
  { name: "Payments", code: "PM006", status: "Inactive", createdOn: "2023-11-30" },
];
