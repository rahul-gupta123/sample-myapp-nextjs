"use client";
import React, { useState } from "react";
import moment from "moment";
import AppLayout from "../../AppLayout";
import { entityColumns, entityData, Entity } from "./entityData";
import { FaChevronLeft, FaChevronRight } from "react-icons/fa";
import { useToast } from "@/components/ToastProvider";

export default function EntityMasterPage() {
  const { showToast } = useToast();
  // Format date-time as DD-MM-YYYY HH:MM AM/PM using moment
  function formatDateTime(dateStr: string) {
    if (!dateStr) return "";
    const m = moment(dateStr);
    if (!m.isValid()) return dateStr;
    return m.format("DD-MM-YYYY hh:mm A");
  }
  const [sortCol, setSortCol] = useState<number>(0);
  const [sortAsc, setSortAsc] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [search, setSearch] = useState<string>("");
  const [pageSize, setPageSize] = useState<number>(5);

  // Filter and sort
  const filteredRows = entityData.filter(entity =>
    Object.values(entity).some(cell => cell.toString().toLowerCase().includes(search.toLowerCase()))
  );
  const keys: (keyof Entity)[] = ["name", "status", "createdOn"];
  const sortedRows = [...filteredRows].sort((a, b) => {
    const key = keys[sortCol];
    const aVal = a[key] ?? "";
    const bVal = b[key] ?? "";
    if (aVal === bVal) return 0;
    if (sortAsc) {
      return aVal > bVal ? 1 : -1;
    } else {
      return aVal < bVal ? 1 : -1;
    }
  });
  const totalPages = Math.ceil(sortedRows.length / pageSize);
  const pagedRows = sortedRows.slice((page - 1) * pageSize, page * pageSize);

  return (
    <AppLayout>
      <div className="min-h-screen bg-gray-100 p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-blue-700">Entity Master</h1>
          <a href="/masters/entity-master/create-entity">
            <button className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 transition">Create</button>
          </a>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Search Filter and Export Button */}
          <div className="mb-4 flex items-center gap-4">
            <input
              type="text"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700"
              placeholder="Search entities..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
            />
            <button
              type="button"
              className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow hover:bg-green-700 transition"
              onClick={() => {
                // Export entire table data (sortedRows) with proper CSV escaping and UTF-8 BOM for Excel compatibility
                const headers = ["Entity Name", "Description", "Status", "Created On"];
                const escapeCSV = (value: string) => {
                  if (value == null) return '';
                  const str = value.toString();
                  // Escape double quotes and wrap in quotes if contains comma, quote, or newline
                  if (/[",\n]/.test(str)) {
                    return '"' + str.replace(/"/g, '""') + '"';
                  }
                  return str;
                };
                // Always export all data from entityData, not just sortedRows
                if (entityData.length === 0) {
                  showToast("No Records To Export", "info");
                  return;
                }
                const rows = entityData.map(entity => [
                  escapeCSV(entity.name),
                  escapeCSV(entity.description ?? ""),
                  escapeCSV(entity.status ? "Active" : "Inactive"),
                  escapeCSV(formatDateTime(entity.createdOn))
                ]);
                let csv = headers.join(",") + "\r\n" + rows.map(r => r.join(",")).join("\r\n");
                // Add UTF-8 BOM for Excel compatibility
                const BOM = "\uFEFF";
                // Force Excel to open as UTF-8 by using .csv extension and BOM
                const blob = new Blob([BOM + csv], { type: "application/vnd.ms-excel" });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = "entities.csv";
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
              }}
            >
              Export
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full border border-gray-200 rounded-lg">
              <thead className="bg-gradient-to-r from-blue-50 to-blue-100">
                <tr>
                  {entityColumns.map((col, i) => (
                    <th
                      key={i}
                      className="px-6 py-4 text-left text-sm font-semibold text-blue-700 uppercase tracking-wide cursor-pointer select-none transition hover:bg-blue-200"
                      onClick={() => { setSortCol(i); setSortAsc(sortCol === i ? !sortAsc : true); }}
                    >
                      <div className="flex items-center">
                        {col}
                        {sortCol === i && (
                          <span className="ml-2 text-blue-500 text-lg">{sortAsc ? "▲" : "▼"}</span>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white">
                {pagedRows.length === 0 ? (
                  <tr>
                    <td colSpan={entityColumns.length} className="px-6 py-8 text-center text-gray-400 text-lg">No data available</td>
                  </tr>
                ) : pagedRows.map((entity, i) => (
                  <tr key={i} className="transition hover:bg-blue-50">
                    <td className="px-6 py-4 whitespace-nowrap text-base text-gray-700 border-b border-gray-100">{entity.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-base text-gray-700 border-b border-gray-100">{entity.status ? "Active" : "Inactive"}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-base text-gray-700 border-b border-gray-100">{formatDateTime(entity.createdOn)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* Pagination Controls */}
          <div className="flex justify-end items-center mt-6 gap-2">
            <div className="flex items-center gap-2">
              <label htmlFor="pageSizeBottom" className="text-gray-600 text-sm font-medium">Show</label>
              <select
                id="pageSizeBottom"
                className="px-2 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700 bg-white"
                value={pageSize}
                onChange={e => { setPageSize(Number(e.target.value)); setPage(1); }}
              >
                {[5, 10, 20, 50].map(size => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
              <span className="text-gray-600 text-sm font-medium">items</span>
            </div>
            <button
              className="p-2 bg-blue-600 text-white rounded-full shadow hover:bg-blue-700 transition disabled:opacity-50 flex items-center justify-center"
              onClick={() => setPage(page - 1)}
              disabled={page === 1}
              aria-label="Previous Page"
            >
              <FaChevronLeft size={20} />
            </button>
            <span className="text-base text-gray-700 font-medium mx-2">Page {page} of {totalPages}</span>
            <button
              className="p-2 bg-blue-600 text-white rounded-full shadow hover:bg-blue-700 transition disabled:opacity-50 flex items-center justify-center"
              onClick={() => setPage(page + 1)}
              disabled={page === totalPages}
              aria-label="Next Page"
            >
              <FaChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

