"use client";
import React from "react";
import AppLayout from "../../../AppLayout";
import { useRouter } from "next/navigation";

export default function CreateEntityPage() {
  const router = useRouter();
  return (
    <AppLayout>
      <div className="min-h-screen bg-gray-100 p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-blue-700">Create Entity</h1>
          <button
            className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 transition"
            onClick={() => router.back()}
          >
            Back
          </button>
        </div>
        <form className="bg-white rounded-xl shadow-lg p-8 max-w-xl mx-auto space-y-6">
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Entity Name</label>
            <input type="text" name="name" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700" placeholder="Enter entity name" required />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Description</label>
            <textarea name="description" rows={3} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700" placeholder="Enter description" />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Status</label>
            <select name="status" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700" required>
              <option value="">Select status</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          <div className="flex justify-end">
            <button type="submit" className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 transition">Save</button>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}
