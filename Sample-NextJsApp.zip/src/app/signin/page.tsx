import AuthPage from "../AuthPage";

export default function SignInPage() {
  return <AuthPage />;
}
