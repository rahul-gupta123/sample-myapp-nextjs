import AuthPage from "../AuthPage";

export default function SignUpPage() {
  return <AuthPage />;
}
