"use client";
import AppLayout from "../../AppLayout";

export default function RoleMasterPage() {
  return (
    <AppLayout>
        <h1 className="text-2xl font-bold mb-4">Welcome to your Role Master!</h1>
    </AppLayout>
  );
}
