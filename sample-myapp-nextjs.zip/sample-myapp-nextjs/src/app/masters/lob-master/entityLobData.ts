export interface Lob {
  id: string;
  name: string;
  code: string;
  entityId: string;
  status: string;
  createdOn: string;
}

export const lobColumns = ["LOB Name", "Code", "Entity Mapping", "Status", "Created On"];

export const lobData: Lob[] = [
  { id: "L001", name: "Retail Banking", code: "RB001", entityId: "E001", status: "Active", createdOn: "2024-01-10" },
  { id: "L002", name: "Corporate Banking", code: "CB002", entityId: "E002", status: "Active", createdOn: "2024-02-15" },
  { id: "L003", name: "Wealth Management", code: "WM003", entityId: "E003", status: "Inactive", createdOn: "2023-12-05" },
  { id: "L004", name: "Insurance", code: "IN004", entityId: "E004", status: "Active", createdOn: "2024-03-20" },
  { id: "L005", name: "Loans", code: "LN005", entityId: "E005", status: "Active", createdOn: "2024-04-11" },
  { id: "L006", name: "Payments", code: "PM006", entityId: "E006", status: "Inactive", createdOn: "2023-11-30" },
];
