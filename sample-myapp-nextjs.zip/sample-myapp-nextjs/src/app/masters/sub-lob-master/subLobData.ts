export interface SubLob {
  id: string;
  name: string;
  code: string;
  lobId: string;
  status: string;
  createdOn: string;
}

export const subLobColumns = ["Sub LOB Name", "Code", "LOB Mapping", "Status", "Created On"];

export const subLobData: SubLob[] = [
  { id: "SL001", name: "Personal Loans", code: "PL001", lobId: "L005", status: "Active", createdOn: "2024-01-10" },
  { id: "SL002", name: "Home Insurance", code: "HI002", lobId: "L004", status: "Active", createdOn: "2024-02-15" },
  { id: "SL003", name: "Savings Accounts", code: "SA003", lobId: "L001", status: "Inactive", createdOn: "2023-12-05" },
  { id: "SL004", name: "Business Loans", code: "BL004", lobId: "L005", status: "Active", createdOn: "2024-03-20" },
  { id: "SL005", name: "Credit Cards", code: "CC005", lobId: "L006", status: "Active", createdOn: "2024-04-11" },
  { id: "SL006", name: "Investment Advisory", code: "IA006", lobId: "L003", status: "Inactive", createdOn: "2023-11-30" },
];
