export interface Entity {
  id: string;
  name: string;
  description?: string;
  status: boolean;
  createdOn: string;
}

export const entityColumns = ["Entity Name", "Status", "Created On"];

export const entityData: Entity[] = [
  { id: "E001", name: "Acme Corp", description: "Global leader in widgets.", status: true, createdOn: "2024-01-10T09:15:00" },
  { id: "E002", name: "Beta LLC", description: "Regional services provider.", status: false, createdOn: "2023-11-22T14:30:00" },
  { id: "E003", name: "Gamma Inc", description: "Financial solutions expert.", status: true, createdOn: "2024-03-05T11:45:00" },
  { id: "E004", name: "Delta Ltd", description: "Insurance and loans specialist.", status: true, createdOn: "2024-05-18T16:00:00" },
  { id: "E005", name: "Epsilon GmbH", description: "European market focus.", status: false, createdOn: "2023-09-30T08:20:00" },
  { id: "E006", name: "Zeta Pvt", description: "Private banking services.", status: true, createdOn: "2024-06-01T10:10:00" },
  { id: "E007", name: "Eta Group", description: "Group of financial entities.", status: true, createdOn: "2024-07-01T13:55:00" },
];
