"use client";
import React, { useState } from "react";
import AppLayout from "../../../AppLayout";
// import { entityData } from "../entityData";
import { useRouter } from "next/navigation";
import { useToast } from "@/components/ToastProvider";

export default function CreateEntityPage() {
  const { showToast } = useToast();
  const router = useRouter();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("");
  const [touched, setTouched] = useState<{ name: boolean; description: boolean; status: boolean }>({ name: false, description: false, status: false });

  const isNameValid = name.trim().length > 0;
  const isDescriptionValid = description.trim().length > 0;
  const isStatusValid = status === "Active" || status === "Inactive";
  const isFormValid = isNameValid && isDescriptionValid && isStatusValid;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTouched({ name: true, description: true, status: true });
    if (!isFormValid) return;
    const newEntity = {
      id: `E${Date.now()}`,
      name: name.trim(),
      description: description.trim(),
      status: status === "Active",
      createdOn: new Date().toISOString(),
    };
    try {
      let res = await fetch("http://localhost:5000/entities", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newEntity),
      });

      if (!res.ok) {
        throw new Error("Failed to save entity");
      }

      setName("");
      setDescription("");
      setStatus("");
      setTouched({ name: false, description: false, status: false });
      router.back();
    } catch (err) {
      // Optionally show a toast for error
      showToast("Failed to save entity. Please try again.", "error");
    }
  };

  return (
    <AppLayout>
      <div className="min-h-screen bg-gray-100 p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-blue-700">Create Entity</h1>
          <button
            className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 transition"
            onClick={() => router.back()}
          >
            Back
          </button>
        </div>
        <form className="bg-white rounded-xl shadow-lg p-8 max-w-xl mx-auto space-y-6" onSubmit={handleSubmit} noValidate>
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Entity Name<span className="text-red-500 ml-1">*</span></label>
            <input
              type="text"
              name="name"
              value={name}
              onChange={e => setName(e.target.value)}
              onBlur={() => setTouched(t => ({ ...t, name: true }))}
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700 ${!isNameValid && touched.name ? "border-red-500" : "border-gray-300"}`}
              placeholder="Enter entity name"
              required
            />
            {!isNameValid && touched.name && (
              <span className="text-red-500 text-sm mt-1 block">Entity Name is required.</span>
            )}
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Description<span className="text-red-500 ml-1">*</span></label>
            <textarea
              name="description"
              value={description}
              onChange={e => setDescription(e.target.value)}
              onBlur={() => setTouched(t => ({ ...t, description: true }))}
              rows={3}
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700 ${!isDescriptionValid && touched.description ? "border-red-500" : "border-gray-300"}`}
              placeholder="Enter description"
              required
            />
            {!isDescriptionValid && touched.description && (
              <span className="text-red-500 text-sm mt-1 block">Description is required.</span>
            )}
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2">Status<span className="text-red-500 ml-1">*</span></label>
            <select
              name="status"
              value={status}
              onChange={e => setStatus(e.target.value)}
              onBlur={() => setTouched(t => ({ ...t, status: true }))}
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700 ${!isStatusValid && touched.status ? "border-red-500" : "border-gray-300"}`}
              required
            >
              <option value="">Select status</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
            {!isStatusValid && touched.status && (
              <span className="text-red-500 text-sm mt-1 block">Status is required.</span>
            )}
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className={`px-6 py-2 font-semibold rounded-lg shadow transition text-white ${isFormValid ? "bg-blue-600 hover:bg-blue-700" : "bg-gray-400 cursor-not-allowed"}`}
              disabled={!isFormValid}
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}
