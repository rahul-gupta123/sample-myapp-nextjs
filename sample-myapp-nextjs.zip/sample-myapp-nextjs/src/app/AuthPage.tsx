"use client";
import { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";

function validateEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export default function AuthPage() {
  const router = useRouter();
  const pathname = usePathname();
  const [tab, setTab] = useState<"signup" | "signin">("signup");
  const [dark, setDark] = useState(false);

  // Sync dark state with <html> class and localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      const isDark = document.documentElement.classList.contains("dark") || localStorage.getItem("theme") === "dark";
      setDark(isDark);
    }
  }, []);

  // When dark changes, update <html> class and localStorage
  const handleThemeToggle = () => {
    if (typeof window !== "undefined") {
      const newDark = !dark;
      setDark(newDark);
      const theme = newDark ? "dark" : "light";
      localStorage.setItem("theme", theme);
      if (theme === "dark") {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
      window.dispatchEvent(new StorageEvent("storage", {
        key: "theme",
        newValue: theme,
        storageArea: localStorage
      }));
    }
  };

  // Signup form state
  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");

  // Signin form state
  const [signinEmail, setSigninEmail] = useState("");
  const [signinPassword, setSigninPassword] = useState("");

  // Validation
  const signupValid = signupName.trim() && validateEmail(signupEmail) && signupPassword.length >= 6;
  const signinValid = validateEmail(signinEmail) && signinPassword.length >= 6;

  // Set tab based on URL
  useEffect(() => {
    if (pathname === "/signin") setTab("signin");
    else setTab("signup");
  }, [pathname]);

  // Reset form fields and validation on tab switch, but do not reset dark mode
  const handleTabSwitch = (newTab: "signup" | "signin") => {
    setTab(newTab);
    setSignupName("");
    setSignupEmail("");
    setSignupPassword("");
    setSigninEmail("");
    setSigninPassword("");
    // Removed router.replace to prevent remount/flicker
  };

  return (
    <div
      className={`flex items-center justify-center min-h-screen p-4 transition-colors duration-300 ${
        dark
          ? "bg-gradient-to-br from-purple-900 via-purple-800 to-purple-950"
          : "bg-gradient-to-br from-purple-100 via-purple-200 to-purple-400"
      }`}
    >
      <div
        className={`relative shadow-2xl rounded-3xl p-12 w-full max-w-lg border-2 border-purple-300/40 backdrop-blur-xl transition-colors duration-300 ${
          dark ? "bg-gradient-to-br from-[#1a1027] via-[#2d1847] to-[#1a1027] border-[#3a225a]" : "bg-white/95 border-purple-200/60"
        }`}
        style={{ boxShadow: dark ? '0 8px 40px 0 rgba(80,40,120,0.45)' : '0 8px 40px 0 rgba(160,80,255,0.15)' }}
      >
        {/* Decorative Circles & Glow */}
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-40 h-40 bg-purple-800/40 rounded-full blur-3xl z-0 animate-pulse" />
        <div className="absolute -bottom-12 right-1/2 translate-x-1/2 w-32 h-32 bg-purple-900/30 rounded-full blur-2xl z-0 animate-pulse" />
        <div className={`absolute -top-8 -left-8 w-24 h-24 rounded-full blur-2xl z-0 transition-colors duration-300 ${dark ? "bg-purple-900/50" : "bg-purple-200/30"}`} />
        <div className={`absolute -bottom-8 -right-8 w-24 h-24 rounded-full blur-2xl z-0 transition-colors duration-300 ${dark ? "bg-purple-800/40" : "bg-purple-400/20"}`} />
        <div className="relative z-10">
          <div className="flex justify-between mb-10 items-center">
            <div className="flex">
              <button
                className={`px-7 py-2 font-bold rounded-l-xl border-r border-purple-200 focus:outline-none transition-all duration-200 text-lg shadow-md ${
                  tab === "signup"
                    ? dark
                      ? "bg-gradient-to-r from-purple-800 to-purple-600 text-white scale-110 shadow-lg"
                      : "bg-gradient-to-r from-purple-600 to-purple-400 text-white scale-110 shadow-lg"
                    : dark
                    ? "bg-purple-900 text-purple-200 hover:bg-purple-800"
                    : "bg-purple-50 text-purple-700 hover:bg-purple-100"
                }`}
                onClick={() => handleTabSwitch("signup")}
                type="button"
              >
                Sign Up
              </button>
              <button
                className={`px-7 py-2 font-bold rounded-r-xl focus:outline-none transition-all duration-200 text-lg shadow-md ${
                  tab === "signin"
                    ? dark
                      ? "bg-gradient-to-r from-purple-800 to-purple-600 text-white scale-110 shadow-lg"
                      : "bg-gradient-to-r from-purple-600 to-purple-400 text-white scale-110 shadow-lg"
                    : dark
                    ? "bg-purple-900 text-purple-200 hover:bg-purple-800"
                    : "bg-purple-50 text-purple-700 hover:bg-purple-100"
                }`}
                onClick={() => handleTabSwitch("signin")}
                type="button"
              >
                Sign In
              </button>
            </div>
            <button
              className={`ml-4 p-2 rounded-full border-2 transition-colors duration-200 shadow-md focus:outline-none ${
                dark
                  ? "bg-purple-900 border-purple-700 text-purple-200 hover:bg-purple-800"
                  : "bg-purple-50 border-purple-200 text-purple-700 hover:bg-purple-100"
              }`}
              onClick={handleThemeToggle}
              aria-label="Toggle dark mode"
              type="button"
              title={dark ? "Switch to light mode" : "Switch to dark mode"}
            >
              {dark ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m8.66-13.66l-.71.71M4.05 19.07l-.71.71M21 12h-1M4 12H3m16.95 7.07l-.71-.71M6.34 6.34l-.71-.71M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12.79A9 9 0 1111.21 3a7 7 0 109.79 9.79z" />
                </svg>
              )}
            </button>
          </div>
          {tab === "signup" ? (
            <form className="space-y-7 animate-fade-in" autoComplete="off">
              <h2
                className={`text-3xl font-extrabold text-center mb-7 tracking-tight drop-shadow-lg ${
                  dark ? "text-purple-200" : "text-purple-700"
                }`}
              >
                Create Account
              </h2>
              <div>
                <label
                  htmlFor="name"
                  className={`block text-sm font-medium mb-1 ${
                    dark ? "text-purple-200" : "text-purple-700"
                  }`}
                >
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  value={signupName}
                  onChange={e => setSignupName(e.target.value)}
                  className={`w-full px-4 py-2 border-2 rounded-xl focus:outline-none focus:ring-2 bg-white placeholder:text-purple-300 shadow-sm text-black ${
                    dark
                      ? "border-[#3a225a] focus:ring-purple-900 bg-[#232038] placeholder:text-purple-300 text-black"
                      : "border-purple-200 focus:ring-purple-400 text-black"
                  }`}
                  placeholder="Your Name"
                />
              </div>
              <div>
                <label
                  htmlFor="email"
                  className={`block text-sm font-medium mb-1 ${
                    dark ? "text-purple-200" : "text-purple-700"
                  }`}
                >
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  required
                  value={signupEmail}
                  onChange={e => setSignupEmail(e.target.value)}
                  className={`w-full px-4 py-2 border-2 rounded-xl focus:outline-none focus:ring-2 bg-white placeholder:text-purple-300 shadow-sm text-black ${
                    dark
                      ? "border-[#3a225a] focus:ring-purple-900 bg-[#232038] placeholder:text-purple-300 text-black"
                      : "border-purple-200 focus:ring-purple-400 text-black"
                  }`}
                  placeholder="you@example.com"
                />
              </div>
              <div>
                <label
                  htmlFor="password"
                  className={`block text-sm font-medium mb-1 ${
                    dark ? "text-purple-200" : "text-purple-700"
                  }`}
                >
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  required
                  minLength={6}
                  value={signupPassword}
                  onChange={e => setSignupPassword(e.target.value)}
                  className={`w-full px-4 py-2 border-2 rounded-xl focus:outline-none focus:ring-2 bg-white placeholder:text-purple-300 shadow-sm text-black ${
                    dark
                      ? "border-[#3a225a] focus:ring-purple-900 bg-[#232038] placeholder:text-purple-300 text-black"
                      : "border-purple-200 focus:ring-purple-400 text-black"
                  }`}
                  placeholder="••••••••"
                />
              </div>
              <button
                type="submit"
                disabled={!signupValid}
                className={`w-full py-2 px-4 font-bold rounded-xl transition-all shadow-xl focus:outline-none focus:ring-2 text-lg mt-2 ${
                  (tab === "signup" ? signupValid : signinValid)
                    ? (dark
                        ? "bg-gradient-to-r from-purple-800 to-purple-600 hover:from-purple-900 hover:to-purple-700 text-purple-100 focus:ring-purple-800"
                        : "bg-gradient-to-r from-purple-600 to-purple-400 hover:from-purple-700 hover:to-purple-500 text-white focus:ring-purple-400")
                    : "bg-gray-300 text-gray-400 cursor-not-allowed"
                }`}
              >
                Sign Up
              </button>
            </form>
          ) : (
            <form className="space-y-7 animate-fade-in" autoComplete="off"
              onSubmit={e => {
                e.preventDefault();
                if (signinValid) {
                  // Only set localStorage.theme before redirect
                  window.localStorage.setItem("theme", dark ? "dark" : "light");
                  router.push("/dashboard");
                }
              }}
            >
              <h2
                className={`text-3xl font-extrabold text-center mb-7 tracking-tight drop-shadow-lg ${
                  dark ? "text-purple-200" : "text-purple-700"
                }`}
              >
                Welcome Back
              </h2>
              <div>
                <label
                  htmlFor="signin-email"
                  className={`block text-sm font-medium mb-1 ${
                    dark ? "text-purple-200" : "text-purple-700"
                  }`}
                >
                  Email
                </label>
                <input
                  type="email"
                  id="signin-email"
                  name="email"
                  required
                  value={signinEmail}
                  onChange={e => setSigninEmail(e.target.value)}
                  className={`w-full px-4 py-2 border-2 rounded-xl focus:outline-none focus:ring-2 bg-white placeholder:text-purple-300 shadow-sm text-black ${
                    dark
                      ? "border-[#3a225a] focus:ring-purple-900 bg-[#232038] placeholder:text-purple-300 text-black"
                      : "border-purple-200 focus:ring-purple-400 text-black"
                  }`}
                  placeholder="you@example.com"
                />
              </div>
              <div>
                <label
                  htmlFor="signin-password"
                  className={`block text-sm font-medium mb-1 ${
                    dark ? "text-purple-200" : "text-purple-700"
                  }`}
                >
                  Password
                </label>
                <input
                  type="password"
                  id="signin-password"
                  name="password"
                  required
                  minLength={6}
                  value={signinPassword}
                  onChange={e => setSigninPassword(e.target.value)}
                  className={`w-full px-4 py-2 border-2 rounded-xl focus:outline-none focus:ring-2 bg-white placeholder:text-purple-300 shadow-sm text-black ${
                    dark
                      ? "border-[#3a225a] focus:ring-purple-900 bg-[#232038] placeholder:text-purple-300 text-black"
                      : "border-purple-200 focus:ring-purple-400 text-black"
                  }`}
                  placeholder="••••••••"
                />
              </div>
              <button
                type="submit"
                disabled={(tab as any) === "signup" ? !signupValid : !signinValid}
                className={`w-full py-2 px-4 font-bold rounded-xl transition-all shadow-xl focus:outline-none focus:ring-2 text-lg mt-2 ${
                  ((tab as any) === "signup" ? signupValid : signinValid)
                    ? (dark
                        ? "bg-gradient-to-r from-purple-800 to-purple-600 hover:from-purple-900 hover:to-purple-700 text-purple-100 focus:ring-purple-800"
                        : "bg-gradient-to-r from-purple-600 to-purple-400 hover:from-purple-700 hover:to-purple-500 text-white focus:ring-purple-400")
                    : "bg-gray-300 text-gray-400 cursor-not-allowed"
                }`}
              >
                {(tab as any) === "signup" ? "Sign Up" : "Sign In"}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
