"use client";
import AppLayout from "../../AppLayout";

export default function UserMasterPage() {
  return (
    <AppLayout>
        <h1 className="text-2xl font-bold mb-4">Welcome to your User Master!</h1>
    </AppLayout>
  );
}
