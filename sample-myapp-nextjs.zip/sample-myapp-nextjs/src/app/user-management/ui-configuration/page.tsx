"use client";
import AppLayout from "../../AppLayout";

export default function UIConfigurationPage() {
  return (
    <AppLayout>
      <h1 className="text-2xl font-bold mb-4">Welcome to your UI Configuration!</h1>
    </AppLayout>
  );
}
