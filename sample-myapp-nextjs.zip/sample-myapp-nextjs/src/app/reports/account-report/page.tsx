"use client";
import AppLayout from "../../AppLayout";

export default function AccountReportPage() {
  return (
    <AppLayout>
      <h1 className="text-2xl font-bold mb-4">Welcome to your Account Report!</h1>
    </AppLayout>
  );
}
