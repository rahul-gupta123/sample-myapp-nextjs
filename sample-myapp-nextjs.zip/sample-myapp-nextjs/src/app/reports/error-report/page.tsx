"use client";
import AppLayout from "../../AppLayout";

export default function ErrorReportPage() {
  return (
    <AppLayout>
      <h1 className="text-2xl font-bold mb-4">Welcome to your Error Report!</h1>
    </AppLayout>
  );
}
