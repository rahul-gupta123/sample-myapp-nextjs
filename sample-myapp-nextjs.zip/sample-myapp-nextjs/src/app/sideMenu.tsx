export interface SideMenuItem {
  label: string;
  path?: string;
  icon?: React.ReactNode;
  children?: SideMenuItem[];
}

export const sideMenu: SideMenuItem[] = [
  {
    label: "Dashboard",
    path: "/dashboard",
  },
  {
    label: "User Management",
    children: [
      {
        label: "User Master",
        path: "/user-management/user-master",
      },
      {
        label: "Role Master",
        path: "/user-management/role-master",
      },
      {
        label: "UI Configuration",
        path: "/user-management/ui-configuration",
      },
    ],
  },
  {
    label: "Masters",
    children: [
      {
        label: "Entity Master",
        path: "/masters/entity-master",
      },
      {
        label: "LOB Master",
        path: "/masters/lob-master",
      },
      {
        label: "Sub LOB Master",
        path: "/masters/sub-lob-master",
      },
    ],
  },
  {
    label: "Reports",
    children: [
      {
        label: "Account Report",
        path: "/reports/account-report",
      },
      {
        label: "Error Report",
        path: "/reports/error-report",
      },
    ],
  },
];
