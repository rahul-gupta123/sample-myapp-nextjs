"use client";
import React, { useState } from "react";
import AppLayout from "../AppLayout";
import { FaUsers, FaBuilding, FaSitemap, FaProjectDiagram, FaChevronLeft, FaChevronRight } from "react-icons/fa";
// import { Line } from "react-chartjs-2";
// Removed unused chart.js imports

const tableConfigs: Record<string, { columns: string[]; rows: (string | number)[][] }> = {
  Users: {
    columns: ["Month", "Users"],
    rows: [
      ["Jan", 1000],
      ["Feb", 1100],
      ["Mar", 1200],
      ["Apr", 1300],
      ["May", 1250],
      ["Jun", 1245],
      ["Jul", 1245],
    ],
  },
  Entity: {
    columns: ["Month", "Entities"],
    rows: [
      ["Jan", 2],
      ["Feb", 3],
      ["Mar", 4],
      ["Apr", 4],
      ["May", 5],
      ["Jun", 5],
      ["Jul", 5],
    ],
  },
  LOBs: {
    columns: ["Month", "LOBs"],
    rows: [
      ["Jan", 8],
      ["Feb", 9],
      ["Mar", 10],
      ["Apr", 11],
      ["May", 12],
      ["Jun", 12],
      ["Jul", 12],
    ],
  },
  "Sub LOBs": {
    columns: ["Month", "Sub LOBs"],
    rows: [
      ["Jan", 20],
      ["Feb", 25],
      ["Mar", 28],
      ["Apr", 30],
      ["May", 32],
      ["Jun", 34],
      ["Jul", 34],
    ],
  },
};

const cardData = [
  {
    title: "Users",
    value: "1,245",
    icon: <FaUsers className="text-blue-600 text-3xl" />,
    bg: "bg-blue-50",
  },
  {
    title: "Entity",
    value: "5",
    icon: <FaBuilding className="text-indigo-600 text-3xl" />,
    bg: "bg-indigo-50",
  },
  {
    title: "LOBs",
    value: "12",
    icon: <FaSitemap className="text-green-600 text-3xl" />,
    bg: "bg-green-50",
  },
  {
    title: "Sub LOBs",
    value: "34",
    icon: <FaProjectDiagram className="text-purple-600 text-3xl" />,
    bg: "bg-purple-50",
  },
];
type CardTitle = "Users" | "Entity" | "LOBs" | "Sub LOBs";

function DashboardPage() {
  const [selectedCard, setSelectedCard] = useState<CardTitle>("Users");
  const [sortCol, setSortCol] = useState<number>(0);
  const [sortAsc, setSortAsc] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [search, setSearch] = useState<string>("");
  const [pageSize, setPageSize] = useState<number>(5);

  const table = tableConfigs[selectedCard];
  // Filter rows by search
  const filteredRows = table.rows.filter(row =>
    row.some(cell => cell.toString().toLowerCase().includes(search.toLowerCase()))
  );
  const sortedRows = [...filteredRows].sort((a, b) => {
    if (a[sortCol] === b[sortCol]) return 0;
    if (sortAsc) {
      return a[sortCol] > b[sortCol] ? 1 : -1;
    } else {
      return a[sortCol] < b[sortCol] ? 1 : -1;
    }
  });
  const totalPages = Math.ceil(sortedRows.length / pageSize);
  const pagedRows = sortedRows.slice((page - 1) * pageSize, page * pageSize);

  return (
    <AppLayout>
      <div className="min-h-screen bg-gray-100 p-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-8">Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {cardData.map((card, idx) => (
            <button
              key={idx}
              className={`flex items-center p-6 rounded-xl shadow ${card.bg} focus:outline-none transition hover:scale-105 ${selectedCard === card.title ? "ring-2 ring-blue-400" : ""}`}
              onClick={() => { setSelectedCard(card.title as CardTitle); setPage(1); }}
              style={{ width: "100%" }}
            >
              <div className="mr-4">{card.icon}</div>
              <div>
                <div className="text-lg font-semibold text-gray-700">{card.title}</div>
                <div className="text-2xl font-bold text-gray-900">{card.value}</div>
              </div>
            </button>
          ))}
        </div>
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
            <span className="inline-block w-2 h-6 bg-blue-500 rounded mr-3"></span>
            {selectedCard} Data
          </h2>
          {/* Search Filter */}
          <div className="mb-4">
            <input
              type="text"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700"
              placeholder={`Search ${selectedCard.toLowerCase()}...`}
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
            />
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full border border-gray-200 rounded-lg">
              <thead className="bg-gradient-to-r from-blue-50 to-blue-100">
                <tr>
                  {table.columns.map((col, i) => (
                    <th
                      key={i}
                      className="px-6 py-4 text-left text-sm font-semibold text-blue-700 uppercase tracking-wide cursor-pointer select-none transition hover:bg-blue-200"
                      onClick={() => { setSortCol(i); setSortAsc(sortCol === i ? !sortAsc : true); }}
                    >
                      <div className="flex items-center">
                        {col}
                        {sortCol === i && (
                          <span className="ml-2 text-blue-500 text-lg">{sortAsc ? "▲" : "▼"}</span>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white">
                {pagedRows.length === 0 ? (
                  <tr>
                    <td colSpan={table.columns.length} className="px-6 py-8 text-center text-gray-400 text-lg">No data available</td>
                  </tr>
                ) : (
                  pagedRows.map((row, i) => (
                    <tr key={i} className="transition hover:bg-blue-50">
                      {row.map((cell, j) => (
                        <td key={j} className="px-6 py-4 whitespace-nowrap text-base text-gray-700 border-b border-gray-100">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {/* Pagination Controls */}
          <div className="flex justify-end items-center mt-6 gap-2">
            <div className="flex items-center gap-2">
              <label htmlFor="pageSizeBottom" className="text-gray-600 text-sm font-medium">Show</label>
              <select
                id="pageSizeBottom"
                className="px-2 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-700 bg-white"
                value={pageSize}
                onChange={e => { setPageSize(Number(e.target.value)); setPage(1); }}
              >
                {[5, 10, 20, 50].map(size => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
              <span className="text-gray-600 text-sm font-medium">items</span>
            </div>
            <button
              className="p-2 bg-blue-600 text-white rounded-full shadow hover:bg-blue-700 transition disabled:opacity-50 flex items-center justify-center"
              onClick={() => setPage(page - 1)}
              disabled={page === 1}
              aria-label="Previous Page"
            >
              <FaChevronLeft size={20} />
            </button>
            <span className="text-base text-gray-700 font-medium mx-2">Page {page} of {totalPages}</span>
            <button
              className="p-2 bg-blue-600 text-white rounded-full shadow hover:bg-blue-700 transition disabled:opacity-50 flex items-center justify-center"
              onClick={() => setPage(page + 1)}
              disabled={page === totalPages}
              aria-label="Next Page"
            >
              <FaChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

export default DashboardPage;
