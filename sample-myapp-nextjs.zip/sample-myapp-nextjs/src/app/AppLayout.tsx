"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { sideMenu } from "./sideMenu";


export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [openMenus, setOpenMenus] = useState<{ [label: string]: boolean }>({});
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== "undefined") {
      let theme = localStorage.getItem("theme");
      if (!theme) {
        theme = "light";
        localStorage.setItem("theme", "light");
      }
      setDarkMode(theme === "dark");
      const onStorage = (e: StorageEvent) => {
        if (e.key === "theme") {
          setDarkMode(e.newValue === "dark");
        }
      };
      window.addEventListener("storage", onStorage);
      return () => window.removeEventListener("storage", onStorage);
    }
  }, []);

  const toggleDarkMode = () => {
    if (typeof window !== "undefined") {
      const newMode = !darkMode;
      setDarkMode(newMode);
      const theme = newMode ? "dark" : "light";
      localStorage.setItem("theme", theme);
      if (theme === "dark") {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
      window.dispatchEvent(new StorageEvent("storage", {
        key: "theme",
        newValue: theme,
        storageArea: localStorage
      }));
    }
  };

  const handleMenuClick = (path: string) => {
    router.push(path);
    if (typeof window !== "undefined" && window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  const handleSubMenuToggle = (label: string) => {
    setOpenMenus((prev) => ({ ...prev, [label]: !prev[label] }));
  };

  return (
    <div className="flex min-h-screen bg-white dark:bg-gray-900">
      {/* Sidebar */}
      <aside
        className={`fixed z-30 inset-y-0 left-0 w-64 transform bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 shadow-lg transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-64"
        }`}
      >
        <div className="flex items-center h-16 px-6 font-bold text-xl text-purple-700 dark:text-purple-200 border-b border-gray-200 dark:border-gray-700">
          MyApp
        </div>
        <nav className="mt-6 px-4 space-y-2">
          {sideMenu.map((item) =>
            !item.children ? (
              <a
                key={item.label}
                href="#"
                className="block py-2 px-4 rounded-lg text-purple-700 dark:text-purple-200 hover:bg-purple-100 dark:hover:bg-[#2d1847] font-medium transition"
                onClick={e => {
                  e.preventDefault();
                  handleMenuClick(item.path!);
                }}
              >
                {item.label}
              </a>
            ) : (
              <div className="group" key={item.label}>
                <button
                  type="button"
                  className="w-full flex items-center justify-between py-2 px-4 rounded-lg text-purple-700 dark:text-purple-200 hover:bg-purple-100 dark:hover:bg-[#2d1847] font-medium transition focus:outline-none"
                  onClick={() => sidebarOpen && handleSubMenuToggle(item.label)}
                  aria-expanded={!!openMenus[item.label]}
                  aria-controls={`submenu-${item.label}`}
                  tabIndex={sidebarOpen ? 0 : -1}
                  disabled={!sidebarOpen}
                >
                  <span>{item.label}</span>
                  <svg className={`ml-2 h-4 w-4 transform transition-transform duration-200 ${openMenus[item.label] ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {sidebarOpen && openMenus[item.label] && (
                  <div id={`submenu-${item.label}`} className="pl-4 mt-1 space-y-1">
                    {item.children.map(child => (
                      <a
                        key={child.label}
                        href="#"
                        className="block py-2 px-4 rounded-lg text-purple-700 dark:text-purple-200 hover:bg-purple-100 dark:hover:bg-[#2d1847] transition text-sm"
                        onClick={e => {
                          e.preventDefault();
                          handleMenuClick(child.path!);
                        }}
                      >
                        {child.label}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )
          )}
        </nav>
      </aside>
      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-black/30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      {/* Main content area */}
      <div
        className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${
          sidebarOpen ? "lg:ml-64" : "lg:ml-0"
        }`}
      >
        {/* Header */}
        <header className="flex items-center h-16 px-4 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 shadow-sm relative z-10">
          {/* Hamburger */}
          <button
            className="p-2 rounded-md text-purple-700 dark:text-purple-200 hover:bg-purple-100 dark:hover:bg-[#2d1847] focus:outline-none mr-4"
            onClick={() => setSidebarOpen((open) => !open)}
            aria-label="Toggle sidebar"
          >
            <svg className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div className="flex-1" />
          {/* Dark/Light mode toggle */}
          <button
            className="p-2 rounded-md text-purple-700 dark:text-purple-200 hover:bg-purple-100 dark:hover:bg-[#2d1847] focus:outline-none mr-2"
            onClick={toggleDarkMode}
            aria-label="Toggle dark mode"
          >
            {darkMode ? (
              <svg className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v1m0 16v1m8.66-13.66l-.71.71M4.05 19.07l-.71.71M21 12h-1M4 12H3m16.95 7.07l-.71-.71M4.05 4.93l-.71-.71M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            ) : (
              <svg className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 12.79A9 9 0 1111.21 3a7 7 0 009.79 9.79z" />
              </svg>
            )}
          </button>
          {/* Profile dropdown */}
          <div className="relative">
            <button
              className="flex items-center justify-center w-10 h-10 rounded-full bg-purple-100 dark:bg-[#2d1847] text-purple-700 dark:text-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400"
              onClick={() => setProfileOpen((open) => !open)}
              aria-label="Open profile menu"
            >
              <svg className="h-7 w-7" fill="currentColor" viewBox="0 0 24 24">
                <circle cx="12" cy="8" r="4" />
                <path d="M4 20c0-2.21 3.58-4 8-4s8 1.79 8 4" />
              </svg>
            </button>
            {profileOpen && (
              <div className="absolute right-0 mt-2 w-44 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg py-2 z-50 animate-fade-in">
                <a
                  href="#"
                  className="block px-4 py-2 text-purple-700 dark:text-purple-200 hover:bg-purple-100 dark:hover:bg-gray-800 transition"
                  onClick={e => {
                    e.preventDefault();
                    setProfileOpen(false);
                    router.push("/profile");
                  }}
                >Profile</a>
                <a
                  href="#"
                  className="block px-4 py-2 text-purple-700 dark:text-purple-200 hover:bg-purple-100 dark:hover:bg-gray-800 transition"
                  onClick={e => {
                    e.preventDefault();
                    setProfileOpen(false);
                    router.push("/signin");
                  }}
                >Logout</a>
              </div>
            )}
          </div>
        </header>
        {/* Main content */}
        <main className="flex-1 p-6 bg-gray-50 text-black transition-colors">
          {children}
        </main>
        {/* Footer */}
        <footer className="w-full px-6 py-4 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 text-center text-sm text-gray-500 dark:text-gray-400">
          © {new Date().getFullYear()} MyApp. All rights reserved.
        </footer>
      </div>
    </div>
  );
}
