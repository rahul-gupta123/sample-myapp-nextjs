"use client";

import AppLayout from "../AppLayout";

export default function ProfilePage() {
  return (
    <AppLayout>
      <h1 className="text-2xl font-bold mb-4">Welcome to your Profile!</h1>
    </AppLayout>
  );
}
