import { Controller, Get, Post, Body } from '@nestjs/common';
import { EntityService } from './entity.service';
import { Entity } from './entity.model';

@Controller('entities')
export class EntityController {
  constructor(private readonly entityService: EntityService) {}

  @Get()
  getAllEntities(): Entity[] {
    return this.entityService.getAllEntities();
  }

  @Post()
  addEntity(@Body() entity: Entity): Entity {
    return this.entityService.addEntity(entity);
  }
}
