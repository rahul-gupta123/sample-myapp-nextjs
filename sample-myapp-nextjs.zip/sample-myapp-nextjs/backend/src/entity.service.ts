import { Injectable } from '@nestjs/common';
import { Entity } from './entity.model';
import * as fs from 'fs';
import * as path from 'path';

const DATA_PATH = path.join(__dirname, '../../entityData.json');

@Injectable()
export class EntityService {
  getAllEntities(): Entity[] {
    if (!fs.existsSync(DATA_PATH)) return [];
    const data = fs.readFileSync(DATA_PATH, 'utf-8');
    return JSON.parse(data);
  }

  addEntity(entity: Entity): Entity {
    const entities = this.getAllEntities();
    entities.push(entity);
    fs.writeFileSync(DATA_PATH, JSON.stringify(entities, null, 2));
    return entity;
  }
}
