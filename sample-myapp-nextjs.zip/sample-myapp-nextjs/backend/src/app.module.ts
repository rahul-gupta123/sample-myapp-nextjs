import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { EntityController } from './entity.controller';
import { EntityService } from './entity.service';

@Module({
  imports: [],
  controllers: [AppController, EntityController],
  providers: [AppService, EntityService],
})
export class AppModule {}
