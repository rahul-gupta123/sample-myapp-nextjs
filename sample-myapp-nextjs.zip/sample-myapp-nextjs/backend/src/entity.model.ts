export interface Entity {
  id: string;
  name: string;
  description?: string;
  status: boolean;
  createdOn: string;
}
